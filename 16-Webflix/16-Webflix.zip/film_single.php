
<?php

// Connexion a BDD
require_once(__DIR__.'/config/database.php'); 



// Recuperer Id dans URL

     // Recuperer l'ID du Film dans l'url
    $film_id = intval($_GET['film_id']) ? $_GET['film_id'] : 0;
    // Recuperer infos sur le film
    $result = $db->prepare('SELECT * FROM film WHERE idFilm=:film_id');  //  :film_id est un paramètre
    $result->bindValue(':film_id',$film_id, PDO ::PARAM_STR); // on s assure que l\'id est bien un entier
    $result->execute(); // Execute la requête
    $film = $result->fetch();

     if($film === false){
         http_response_code(404);
         require_once(__DIR__.'/partials/header.php'); ?>
         <h1>404. Redirection dans 5 secondes ...</h1>; 
         <script>
             setTimeout(function () {
                 window.location = 'film_list.php';
            }, 5000);
        </script>
         <?php require_once(__DIR__.'/partials/footer.php');
         die();
     }

    $currentPageTitle = $film['title'];
    // Le fichier header.php est inclus sur la page
    require_once(__DIR__.'/partials/header.php'); ?>

   
   <h1 class="margin"><?php echo $film['title']; ?></h1><br/>
        
        <div class="row">
            <div class="col-sm-3"><img class="card-img-top mini card-img-fluid" src="assets/<?php echo $film['cover']; ?>"
            alt="<?php echo $film['cover']; ?>"></div>
            <div class="col-sm-5 "><h4>DESCRIPTION</h4><br/> 
            <br/><h6 class="card-title"><?php echo $film['description']; ?></h6><br/> <br/>
            <h5 class="card-title">Date de sortie : <?php echo substr($film['release_at'], 0, 10); ?></h5>
            </div>

            <div class="col-sm-4"><iframe width="530" height="285" src="<?php echo $film['video_link']; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

       </div>

        <p><a href="film_remove.php?film_id=".$film><INPUT TYPE=SUBMIT VALUE='supprimer' NAME='supprimer' ></a></p>






    

<?php
// Le fichier footer.php est inclus sur la page
require_once(__DIR__.'/partials/footer.php'); ?>