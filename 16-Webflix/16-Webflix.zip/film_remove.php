<?php
        
// Connexion a BDD
require_once(__DIR__.'/config/database.php'); 




     //Tu recuperes l'id du contact
     $idFilm = $_GET["film_id"];
     //Requete SQL pour supprimer le contact dans la base
     $query = $db->query('DELETE * FROM film WHERE film_id=:idFilm');
     $query->bindValue(':idFilm', $film_id, PDO::PARAM_INT);
     $query->execute();


     ?>